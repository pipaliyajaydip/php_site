<?php
    session_start();
  
    include('connection.php');    
    $username = $_POST['username'];  
    $password = $_POST['password']; 

    $error = "username or password is incorrect"; 
       
        $username = stripcslashes($username);  
        $password = stripcslashes($password);  
        $username = mysqli_real_escape_string($con, $username);  
        $password = mysqli_real_escape_string($con, $password);  
      
        $sql = "SELECT * from users where email = '$username' and password = '$password'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){  
            echo "<h1><center> Login successful </center></h1>"; 
            $_SESSION['username'] = $username;
            header("location: ../success.html");
            $sql = "UPDATE users SET last_login_date = NOW() WHERE user_id = ".$_SESSION['user_id'];
            $result = mysqli_query($con, $sql);
        }  
        else{  
            echo "<h1> Login failed. Invalid username or password.</h1>"; 
            $_SESSION['error'] = $error;
            header("location: ../auth_login_boxed.php");
        }     
?>  